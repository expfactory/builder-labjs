Stroop task
===========

An implementation of the classic paradigm introduced by Stroop (1935).
----

Built by [Felix Henninger](http://felixhenninger.com) with [lab.js](https://felixhenninger.github.io/lab.js)